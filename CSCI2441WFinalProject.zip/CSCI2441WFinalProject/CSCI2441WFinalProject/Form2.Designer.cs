﻿namespace CSCI2441WFinalProject
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSName = new System.Windows.Forms.Label();
            this.lblSID = new System.Windows.Forms.Label();
            this.txbSName = new System.Windows.Forms.TextBox();
            this.txbSID = new System.Windows.Forms.TextBox();
            this.lblSBT = new System.Windows.Forms.Label();
            this.rbnSP = new System.Windows.Forms.RadioButton();
            this.rbnSD = new System.Windows.Forms.RadioButton();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvViewer = new System.Windows.Forms.DataGridView();
            this.btnMaxPatients = new System.Windows.Forms.Button();
            this.btnMinPatients = new System.Windows.Forms.Button();
            this.btnMaxDonors = new System.Windows.Forms.Button();
            this.btnMinDonors = new System.Windows.Forms.Button();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.rbnAD = new System.Windows.Forms.RadioButton();
            this.rbnAP = new System.Windows.Forms.RadioButton();
            this.lblABT = new System.Windows.Forms.Label();
            this.txbAID = new System.Windows.Forms.TextBox();
            this.txbAName = new System.Windows.Forms.TextBox();
            this.lblAID = new System.Windows.Forms.Label();
            this.lblAName = new System.Windows.Forms.Label();
            this.cbxSBT = new System.Windows.Forms.ComboBox();
            this.cbxABT = new System.Windows.Forms.ComboBox();
            this.txbAReport = new System.Windows.Forms.TextBox();
            this.lblAReport = new System.Windows.Forms.Label();
            this.txbAContact = new System.Windows.Forms.TextBox();
            this.lblAContact = new System.Windows.Forms.Label();
            this.txbAAddress = new System.Windows.Forms.TextBox();
            this.lblAAddress = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewer)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSName
            // 
            this.lblSName.AutoSize = true;
            this.lblSName.Location = new System.Drawing.Point(71, 73);
            this.lblSName.Name = "lblSName";
            this.lblSName.Size = new System.Drawing.Size(38, 13);
            this.lblSName.TabIndex = 0;
            this.lblSName.Text = "Name:";
            // 
            // lblSID
            // 
            this.lblSID.AutoSize = true;
            this.lblSID.Location = new System.Drawing.Point(88, 114);
            this.lblSID.Name = "lblSID";
            this.lblSID.Size = new System.Drawing.Size(21, 13);
            this.lblSID.TabIndex = 1;
            this.lblSID.Text = "ID:";
            // 
            // txbSName
            // 
            this.txbSName.Location = new System.Drawing.Point(115, 70);
            this.txbSName.Name = "txbSName";
            this.txbSName.Size = new System.Drawing.Size(100, 20);
            this.txbSName.TabIndex = 2;
            // 
            // txbSID
            // 
            this.txbSID.Location = new System.Drawing.Point(115, 111);
            this.txbSID.Name = "txbSID";
            this.txbSID.Size = new System.Drawing.Size(100, 20);
            this.txbSID.TabIndex = 3;
            // 
            // lblSBT
            // 
            this.lblSBT.AutoSize = true;
            this.lblSBT.Location = new System.Drawing.Point(238, 73);
            this.lblSBT.Name = "lblSBT";
            this.lblSBT.Size = new System.Drawing.Size(64, 13);
            this.lblSBT.TabIndex = 4;
            this.lblSBT.Text = "Blood Type:";
            // 
            // rbnSP
            // 
            this.rbnSP.AutoSize = true;
            this.rbnSP.Location = new System.Drawing.Point(241, 98);
            this.rbnSP.Name = "rbnSP";
            this.rbnSP.Size = new System.Drawing.Size(58, 17);
            this.rbnSP.TabIndex = 7;
            this.rbnSP.TabStop = true;
            this.rbnSP.Text = "Patient";
            this.rbnSP.UseVisualStyleBackColor = true;
            // 
            // rbnSD
            // 
            this.rbnSD.AutoSize = true;
            this.rbnSD.Location = new System.Drawing.Point(241, 121);
            this.rbnSD.Name = "rbnSD";
            this.rbnSD.Size = new System.Drawing.Size(54, 17);
            this.rbnSD.TabIndex = 8;
            this.rbnSD.TabStop = true;
            this.rbnSD.Text = "Donor";
            this.rbnSD.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(308, 109);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 23);
            this.btnSearch.TabIndex = 9;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lblTitle.Location = new System.Drawing.Point(220, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(75, 25);
            this.lblTitle.TabIndex = 10;
            this.lblTitle.Text = "Search";
            // 
            // dgvViewer
            // 
            this.dgvViewer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvViewer.Location = new System.Drawing.Point(40, 144);
            this.dgvViewer.Name = "dgvViewer";
            this.dgvViewer.Size = new System.Drawing.Size(418, 150);
            this.dgvViewer.TabIndex = 11;
            // 
            // btnMaxPatients
            // 
            this.btnMaxPatients.Location = new System.Drawing.Point(40, 300);
            this.btnMaxPatients.Name = "btnMaxPatients";
            this.btnMaxPatients.Size = new System.Drawing.Size(100, 23);
            this.btnMaxPatients.TabIndex = 12;
            this.btnMaxPatients.Text = "Most Needed";
            this.btnMaxPatients.UseVisualStyleBackColor = true;
            // 
            // btnMinPatients
            // 
            this.btnMinPatients.Location = new System.Drawing.Point(146, 300);
            this.btnMinPatients.Name = "btnMinPatients";
            this.btnMinPatients.Size = new System.Drawing.Size(100, 23);
            this.btnMinPatients.TabIndex = 13;
            this.btnMinPatients.Text = "Least Needed";
            this.btnMinPatients.UseVisualStyleBackColor = true;
            // 
            // btnMaxDonors
            // 
            this.btnMaxDonors.Location = new System.Drawing.Point(252, 300);
            this.btnMaxDonors.Name = "btnMaxDonors";
            this.btnMaxDonors.Size = new System.Drawing.Size(100, 23);
            this.btnMaxDonors.TabIndex = 14;
            this.btnMaxDonors.Text = "Most Available";
            this.btnMaxDonors.UseVisualStyleBackColor = true;
            // 
            // btnMinDonors
            // 
            this.btnMinDonors.Location = new System.Drawing.Point(358, 300);
            this.btnMinDonors.Name = "btnMinDonors";
            this.btnMinDonors.Size = new System.Drawing.Size(100, 23);
            this.btnMinDonors.TabIndex = 15;
            this.btnMinDonors.Text = "Least Available";
            this.btnMinDonors.UseVisualStyleBackColor = true;
            // 
            // lblTitle2
            // 
            this.lblTitle2.AutoSize = true;
            this.lblTitle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lblTitle2.Location = new System.Drawing.Point(220, 358);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(48, 25);
            this.lblTitle2.TabIndex = 16;
            this.lblTitle2.Text = "Add";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(339, 509);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 23);
            this.btnAdd.TabIndex = 25;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // rbnAD
            // 
            this.rbnAD.AutoSize = true;
            this.rbnAD.Location = new System.Drawing.Point(40, 418);
            this.rbnAD.Name = "rbnAD";
            this.rbnAD.Size = new System.Drawing.Size(54, 17);
            this.rbnAD.TabIndex = 24;
            this.rbnAD.TabStop = true;
            this.rbnAD.Text = "Donor";
            this.rbnAD.UseVisualStyleBackColor = true;
            // 
            // rbnAP
            // 
            this.rbnAP.AutoSize = true;
            this.rbnAP.Location = new System.Drawing.Point(40, 395);
            this.rbnAP.Name = "rbnAP";
            this.rbnAP.Size = new System.Drawing.Size(58, 17);
            this.rbnAP.TabIndex = 23;
            this.rbnAP.TabStop = true;
            this.rbnAP.Text = "Patient";
            this.rbnAP.UseVisualStyleBackColor = true;
            // 
            // lblABT
            // 
            this.lblABT.AutoSize = true;
            this.lblABT.Location = new System.Drawing.Point(269, 398);
            this.lblABT.Name = "lblABT";
            this.lblABT.Size = new System.Drawing.Size(64, 13);
            this.lblABT.TabIndex = 21;
            this.lblABT.Text = "Blood Type:";
            // 
            // txbAID
            // 
            this.txbAID.Location = new System.Drawing.Point(146, 436);
            this.txbAID.Name = "txbAID";
            this.txbAID.Size = new System.Drawing.Size(100, 20);
            this.txbAID.TabIndex = 20;
            // 
            // txbAName
            // 
            this.txbAName.Location = new System.Drawing.Point(146, 395);
            this.txbAName.Name = "txbAName";
            this.txbAName.Size = new System.Drawing.Size(100, 20);
            this.txbAName.TabIndex = 19;
            // 
            // lblAID
            // 
            this.lblAID.AutoSize = true;
            this.lblAID.Location = new System.Drawing.Point(119, 439);
            this.lblAID.Name = "lblAID";
            this.lblAID.Size = new System.Drawing.Size(21, 13);
            this.lblAID.TabIndex = 18;
            this.lblAID.Text = "ID:";
            // 
            // lblAName
            // 
            this.lblAName.AutoSize = true;
            this.lblAName.Location = new System.Drawing.Point(102, 398);
            this.lblAName.Name = "lblAName";
            this.lblAName.Size = new System.Drawing.Size(38, 13);
            this.lblAName.TabIndex = 17;
            this.lblAName.Text = "Name:";
            // 
            // cbxSBT
            // 
            this.cbxSBT.FormattingEnabled = true;
            this.cbxSBT.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.cbxSBT.Location = new System.Drawing.Point(308, 69);
            this.cbxSBT.Name = "cbxSBT";
            this.cbxSBT.Size = new System.Drawing.Size(121, 21);
            this.cbxSBT.TabIndex = 26;
            // 
            // cbxABT
            // 
            this.cbxABT.FormattingEnabled = true;
            this.cbxABT.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.cbxABT.Location = new System.Drawing.Point(339, 395);
            this.cbxABT.Name = "cbxABT";
            this.cbxABT.Size = new System.Drawing.Size(121, 21);
            this.cbxABT.TabIndex = 27;
            // 
            // txbAReport
            // 
            this.txbAReport.Location = new System.Drawing.Point(339, 432);
            this.txbAReport.Name = "txbAReport";
            this.txbAReport.Size = new System.Drawing.Size(100, 20);
            this.txbAReport.TabIndex = 29;
            // 
            // lblAReport
            // 
            this.lblAReport.AutoSize = true;
            this.lblAReport.Location = new System.Drawing.Point(291, 436);
            this.lblAReport.Name = "lblAReport";
            this.lblAReport.Size = new System.Drawing.Size(42, 13);
            this.lblAReport.TabIndex = 28;
            this.lblAReport.Text = "Report:";
            // 
            // txbAContact
            // 
            this.txbAContact.Location = new System.Drawing.Point(146, 474);
            this.txbAContact.Name = "txbAContact";
            this.txbAContact.Size = new System.Drawing.Size(100, 20);
            this.txbAContact.TabIndex = 31;
            // 
            // lblAContact
            // 
            this.lblAContact.AutoSize = true;
            this.lblAContact.Location = new System.Drawing.Point(93, 477);
            this.lblAContact.Name = "lblAContact";
            this.lblAContact.Size = new System.Drawing.Size(47, 13);
            this.lblAContact.TabIndex = 30;
            this.lblAContact.Text = "Contact:";
            // 
            // txbAAddress
            // 
            this.txbAAddress.Location = new System.Drawing.Point(339, 474);
            this.txbAAddress.Name = "txbAAddress";
            this.txbAAddress.Size = new System.Drawing.Size(100, 20);
            this.txbAAddress.TabIndex = 33;
            // 
            // lblAAddress
            // 
            this.lblAAddress.AutoSize = true;
            this.lblAAddress.Location = new System.Drawing.Point(285, 477);
            this.lblAAddress.Name = "lblAAddress";
            this.lblAAddress.Size = new System.Drawing.Size(48, 13);
            this.lblAAddress.TabIndex = 32;
            this.lblAAddress.Text = "Address:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 593);
            this.Controls.Add(this.txbAAddress);
            this.Controls.Add(this.lblAAddress);
            this.Controls.Add(this.txbAContact);
            this.Controls.Add(this.lblAContact);
            this.Controls.Add(this.txbAReport);
            this.Controls.Add(this.lblAReport);
            this.Controls.Add(this.cbxABT);
            this.Controls.Add(this.cbxSBT);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.rbnAD);
            this.Controls.Add(this.rbnAP);
            this.Controls.Add(this.lblABT);
            this.Controls.Add(this.txbAID);
            this.Controls.Add(this.txbAName);
            this.Controls.Add(this.lblAID);
            this.Controls.Add(this.lblAName);
            this.Controls.Add(this.lblTitle2);
            this.Controls.Add(this.btnMinDonors);
            this.Controls.Add(this.btnMaxDonors);
            this.Controls.Add(this.btnMinPatients);
            this.Controls.Add(this.btnMaxPatients);
            this.Controls.Add(this.dgvViewer);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.rbnSD);
            this.Controls.Add(this.rbnSP);
            this.Controls.Add(this.lblSBT);
            this.Controls.Add(this.txbSID);
            this.Controls.Add(this.txbSName);
            this.Controls.Add(this.lblSID);
            this.Controls.Add(this.lblSName);
            this.Name = "Form2";
            this.Text = "Dashboard";
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSName;
        private System.Windows.Forms.Label lblSID;
        private System.Windows.Forms.TextBox txbSName;
        private System.Windows.Forms.TextBox txbSID;
        private System.Windows.Forms.Label lblSBT;
        private System.Windows.Forms.RadioButton rbnSP;
        private System.Windows.Forms.RadioButton rbnSD;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvViewer;
        private System.Windows.Forms.Button btnMaxPatients;
        private System.Windows.Forms.Button btnMinPatients;
        private System.Windows.Forms.Button btnMaxDonors;
        private System.Windows.Forms.Button btnMinDonors;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.RadioButton rbnAD;
        private System.Windows.Forms.RadioButton rbnAP;
        private System.Windows.Forms.Label lblABT;
        private System.Windows.Forms.TextBox txbAID;
        private System.Windows.Forms.TextBox txbAName;
        private System.Windows.Forms.Label lblAID;
        private System.Windows.Forms.Label lblAName;
        private System.Windows.Forms.ComboBox cbxSBT;
        private System.Windows.Forms.ComboBox cbxABT;
        private System.Windows.Forms.TextBox txbAReport;
        private System.Windows.Forms.Label lblAReport;
        private System.Windows.Forms.TextBox txbAContact;
        private System.Windows.Forms.Label lblAContact;
        private System.Windows.Forms.TextBox txbAAddress;
        private System.Windows.Forms.Label lblAAddress;
    }
}